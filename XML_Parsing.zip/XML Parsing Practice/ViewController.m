//
//  ViewController.m
//  XML Parsing Practice
//
//  Created by Student 6 on 12/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import "ViewController.h"
#import "CustomTableViewCell.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self ParsingXML];
    NSLog(@"%@",MutArray);
    
    if (MutArray.count) {
        _tbleView.delegate = self;
        _tbleView.dataSource = self;
        [_tbleView reloadData];

    }
    
    
    // Do any additional setup after loading the view, typically from a nib.
}


-(void)ParsingXML
{
    NSString *str = @"http://images.apple.com/main/rss/hotnews/hotnews.rss#sthash.4v1dZZzC.dpuf";
    NSURL *url = [NSURL URLWithString:str];
    NSXMLParser *xmlParse = [[NSXMLParser alloc]initWithContentsOfURL:url];
    xmlParse.delegate = self;
    
    [xmlParse parse];
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName attributes:(NSDictionary<NSString *, NSString *> *)attributeDict
{
    if ([elementName isEqualToString:@"channel"]) {
        
        MutArray = [[NSMutableArray alloc]init];
    }
    
    if ([elementName isEqualToString:@"item"]) {
        
        MutDictItem = [[NSMutableDictionary alloc]init];
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    if (MutStr == nil) {
        
        MutStr = [[NSMutableString alloc]init];
        MutStr = [string mutableCopy];
    }
    else
    {
        
      NSString *str = [NSString stringWithFormat:@"%@ %@",MutStr,string];
        str=[str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        MutStr = [str mutableCopy];
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(nullable NSString *)namespaceURI qualifiedName:(nullable NSString *)qName
{
    
    if ([elementName isEqualToString:@"item"]) {
        
        [MutArray addObject:MutDictItem ];
    }
    else
    {
        [MutDictItem setObject:MutStr forKey:elementName];
    }
    
    MutStr = nil;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return MutArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        
        cell = [[CustomTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        
    }
    
    NSDictionary *dicNew = [MutArray objectAtIndex:indexPath.row];
    
    cell.lblTitle.text = [NSString stringWithFormat:@"%@",[dicNew valueForKey:@"title"]];
    cell.lblLink.text = [NSString stringWithFormat:@"%@", [dicNew valueForKey:@"link"]];
    cell.lblDesc.text = [NSString stringWithFormat:@"%@", [dicNew valueForKey:@"description"]];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
