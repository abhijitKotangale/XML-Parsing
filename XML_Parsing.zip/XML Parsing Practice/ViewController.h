//
//  ViewController.h
//  XML Parsing Practice
//
//  Created by Student 6 on 12/04/17.
//  Copyright © 2017 felix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate, UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *MutArray;
    NSMutableDictionary *MutDictItem;
    NSMutableString *MutStr;
}

@property (weak, nonatomic) IBOutlet UITableView *tbleView;

@end

